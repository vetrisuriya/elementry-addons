<?php

namespace ElementryAddons\Widgets;

class Simple_Card extends \Elementor\Widget_Base {

    public function get_name(): string {
		return 'simple-card';
	}

    public function get_title(): string {
		return esc_html__( 'Simple Card', 'elementry-addons' );
	}

    public function get_icon(): string {
		return 'eicon-info-box';
	}

	public function get_categories(): array {
		return [ 'elementry-addons-category' ];
	}

	public function get_keywords(): array {
		return [ 'card', 'elementry', 'simple', 'simple card', 'addon' ];
	}

	public function get_style_depends(): array {
		return [ 'font-awesome-style', 'widget-custom-style', 'simple-card-main-style' ];
	}

	protected function register_controls(): void {

		// Content Tab Start
		$this->start_controls_section(
			'simple_card_content_section',
			[
				'label' => esc_html__( 'Content', 'elementry-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'simple_card_image_input',
			[
				'label' => esc_html__( 'Choose Image', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'simple_card_title_input',
			[
				'label' => esc_html__( 'Title', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'A developer codes software and websites.', 'elementry-addons' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'simple_card_subtitle_input',
			[
				'label' => esc_html__( 'Subtitle', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Developer', 'elementry-addons' ),
			]
		);
		$this->add_control(
			'simple_card_url_input',
			[
				'label' => esc_html__( 'URL to Link', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => esc_html__( 'https://www.vetrisuriya.in/', 'elementry-addons' ),
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
		$this->add_control(
			'simple_card_url_icon_switcher',
			[
				'label' => esc_html__( 'Show Icon', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'elementry-addons' ),
				'label_off' => esc_html__( 'Hide', 'elementry-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->end_controls_section();
		// Content Tab End


		// Style Tab Start
		// Title Styles
		$this->start_controls_section(
			'simple_card_style_title_section',
			[
				'label' => esc_html__( 'Title', 'elementry-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'simple_card_style_title_typo',
				'selector' => '{{WRAPPER}} .elementry-simple_card-item h3',
			]
		);
		$this->start_controls_tabs(
			'simple_card_style_title_tabs'
		);
			$this->start_controls_tab(
				'simple_card_style_title_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'elementry-addons' ),
				]
			);
			$this->add_control(
				'simple_card_style_title_color',
				[
					'label' => esc_html__( 'Color', 'elementry-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#000',
					'selectors' => [
						'{{WRAPPER}} .elementry-simple_card-item h3' => 'color: {{VALUE}}',
					],
				]
			);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'simple_card_style_title_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'elementry-addons' ),
				]
			);
			$this->add_control(
				'simple_card_style_title_hover_color',
				[
					'label' => esc_html__( 'Color', 'elementry-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#B22485',
					'selectors' => [
						'{{WRAPPER}} .elementry-simple_card-item:hover h3' => 'color: {{VALUE}}',
					],
				]
			);
			$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();


		// Subtitle Styles
		$this->start_controls_section(
			'simple_card_style_subtitle_section',
			[
				'label' => esc_html__( 'Subtitle', 'elementry-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'simple_card_style_subtitle__typo',
				'selector' => '{{WRAPPER}} .elementry-simple_card-item span',
			]
		);
		$this->add_control(
			'simple_card_style_subtitle_color',
			[
				'label' => esc_html__( 'Color', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#B22485',
				'selectors' => [
					'{{WRAPPER}} .elementry-simple_card-item span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'simple_card_style_subtitle_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#F7DFF5',
				'selectors' => [
					'{{WRAPPER}} .elementry-simple_card-item span' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'simple_card_style_subtitle_alignment',
			[
				'label' => esc_html__( 'Alignment', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'elementry-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'elementry-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'Right', 'elementry-addons' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'flex-start',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .elementry-simple_card-item span' => 'align-self: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		// Image Styles
		$this->start_controls_section(
			'simple_card_style_img_section',
			[
				'label' => esc_html__( 'Image', 'elementry-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'simple_card_style_img_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default' => [
					'top' => 8,
					'right' => 8,
					'bottom' => 8,
					'left' => 8,
					'unit' => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .elementry-simple_card-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		// Card Styles
		$this->start_controls_section(
			'simple_card_style_section',
			[
				'label' => esc_html__( 'Card Design', 'elementry-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'simple_card_style_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .elementry-simple_card-item' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'simple_card_style_border',
				'selector' => '{{WRAPPER}} .elementry-simple_card-item',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'simple_card_style_box_shadow',
				'selector' => '{{WRAPPER}} .elementry-simple_card-item',
			]
		);
		$this->add_control(
			'simple_card_style_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default' => [
					'top' => 8,
					'right' => 8,
					'bottom' => 8,
					'left' => 8,
					'unit' => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .elementry-simple_card-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// Style Tab End

	}

	protected function render(): void {
		$settings = $this->get_settings_for_display();

		// card url
		if( ! empty( $settings['simple_card_url_input']['url'] ) ) {
			$this->add_link_attributes( 'simple_card_url_input', $settings['simple_card_url_input'] );
		}

		// card image
		$var_image = (isset($settings['simple_card_image_input']['url']) && esc_url( $settings['simple_card_image_input']['url'] ) != "") ? esc_url( $settings['simple_card_image_input']['url'] ) : esc_url( plugins_url( '../assets/images/designer.jpg', __FILE__ ) );

		?>
			<a <?php $this->print_render_attribute_string( 'simple_card_url_input' ); ?> class="elementry-simple_card-item">
				<img src="<?php echo esc_url( $var_image ); ?>" alt="Elementry Simple Card Image">
				<?php
				if(isset($settings["simple_card_subtitle_input"]) && esc_html( $settings["simple_card_subtitle_input"] ) != "") {
				?>
					<span><?php echo esc_html( $settings["simple_card_subtitle_input"] ); ?></span>
				<?php
				}
				?>
				<h3><?php echo esc_html( $settings["simple_card_title_input"] ); ?></h3>
				<?php
				if('yes' === $settings['simple_card_url_icon_switcher'] ) {
				?>
				<div class="arrow-ico">
					<i class="fas fa-arrow-right card-icon"></i>
				</div>
				<?php
				}
				?>
			</a>
		<?php
	}

	protected function content_template(): void {}

}

\Elementor\Plugin::instance()->widgets_manager->register( new \ElementryAddons\Widgets\Simple_Card() );
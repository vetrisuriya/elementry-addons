<?php

namespace ElementryAddons\Widgets;

class Pulse_Effect extends \Elementor\Widget_Base {

    public function get_name(): string {
		return 'pulse-effect';
	}

    public function get_title(): string {
		return esc_html__( 'Pulse Effect', 'elementry-addons' );
	}

    public function get_icon(): string {
		return 'eicon-circle-o';
	}

	public function get_categories(): array {
		return [ 'elementry-addons-category' ];
	}

	public function get_keywords(): array {
		return [ 'elementry', 'addon', 'pulse', 'simple', 'hover' ];
	}

	public function get_style_depends(): array {
		return [ 'pulse-effect-main-style' ];
	}

	protected function register_controls(): void {

		// Content Tab Start
		$this->start_controls_section(
			'pulse_effect_content_section',
			[
				'label' => esc_html__( 'Content', 'elementry-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'pulse_effect_image_input',
			[
				'label' => esc_html__( 'Choose Image', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => plugins_url( '../assets/images/sticker.png', __FILE__ ),
				],
			]
		);
		$this->add_control(
			'pulse_effect_image_h_input',
			[
				'label' => esc_html__( 'Height', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .elementry-pulse_effect #main' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementry-pulse_effect #wave' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementry-pulse_effect #wave2' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'pulse_effect_image_w_input',
			[
				'label' => esc_html__( 'Width', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .elementry-pulse_effect #main' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementry-pulse_effect #wave' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementry-pulse_effect #wave2' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'pulse_effect_url_input',
			[
				'label' => esc_html__( 'URL to Link', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => esc_html__( 'https://www.vetrisuriya.in/', 'elementry-addons' ),
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
		$this->end_controls_section();
		// Content Tab End


		// Style Tab Start
		// Image Styles
		$this->start_controls_section(
			'pulse_effect_style_btn_section',
			[
				'label' => esc_html__( 'Button', 'elementry-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'pulse_effect_style_btn_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#673ab7',
				'selectors' => [
					'{{WRAPPER}} .elementry-pulse_effect #main' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'pulse_effect_style_btn_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default' => [
					'top' => 50,
					'right' => 50,
					'bottom' => 50,
					'left' => 50,
					'unit' => '%',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .elementry-pulse_effect #main' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .elementry-pulse_effect #wave' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .elementry-pulse_effect #wave2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'pulse_effect_style_btn_padding',
			[
				'label' => esc_html__( 'Padding', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default' => [
					'top' => 10,
					'right' => 10,
					'bottom' => 10,
					'left' => 10,
					'unit' => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .elementry-pulse_effect #main' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		// Pulse effect Styles
		$this->start_controls_section(
			'pulse_effect_style_pulse_section',
			[
				'label' => esc_html__( 'Pulse Effect', 'elementry-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'pulse_effect_style_pulse_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'elementry-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => 'silver',
				'selectors' => [
					'{{WRAPPER}} .elementry-pulse_effect #wave' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .elementry-pulse_effect #wave2' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		
	}

	protected function render(): void {
		$settings = $this->get_settings_for_display();

		if ( ! empty( $settings['pulse_effect_url_input']['url'] ) ) {
			$this->add_link_attributes( 'pulse_effect_url_input', $settings['pulse_effect_url_input'] );
		}

		?>
			<a class="elementry-pulse_effect" <?php $this->print_render_attribute_string( 'pulse_effect_url_input' ); ?>>
				<div id="main">
					<img src="<?php echo $settings['pulse_effect_image_input']['url']; ?>"/>
				</div>
				<div id="wave"></div>
				<div id="wave2"></div>
			</a>
		<?php
	}

	protected function content_template(): void {}

}

\Elementor\Plugin::instance()->widgets_manager->register( new \ElementryAddons\Widgets\Pulse_Effect() );
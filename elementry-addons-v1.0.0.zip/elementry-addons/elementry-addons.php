<?php

/**
 * Plugin Name: Elementry Addons
 * Description: This plugin gives you a several components like team card, pricing component, reviews, buttons, inputs and other components.
 * Plugin URI: https://elementry.vetrisuriya.in/elementry-addons
 * Version:     1.0.0
 * Author:      Vetri Suriya
 * Author URI:  https://www.vetrisuriya.in/
 * Text Domain: elementry-addons
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Requires Plugins: elementor
 * Elementor tested up to: 3.25.0
 * Elementor Pro tested up to: 3.25.0
 */

namespace ElementryAddons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Elementry {

	private const PLUGIN_VERSION = "1.0.0";

	// hooks methods
    public function __construct() {
        add_action( 'wp_enqueue_scripts', [ $this, 'register_elementry_addons_assets' ] );
        add_action( 'elementor/init', [ $this, 'register_elementry_addons_category' ] );
        add_action( 'elementor/widgets/register', [ $this, 'register_elementry_addons_widgets' ] );
    }

	// register styles & scripts
	public function register_elementry_addons_assets() {

		// common styles & scripts
		wp_enqueue_style( 'font-awesome-style', plugins_url( 'assets/css/all.min.css', __FILE__ ), [], self::PLUGIN_VERSION, 'all' );

		// simple card styles & scripts
		wp_enqueue_style( 'simple-card-main-style', plugins_url( 'assets/css/simple-card-main-style.css', __FILE__ ), [], self::PLUGIN_VERSION, 'all' );

        // pulse effect styles & scripts
		wp_enqueue_style( 'pulse-effect-main-style', plugins_url( 'assets/css/pulse-effect-main-style.css', __FILE__ ), [], self::PLUGIN_VERSION, 'all' );

		// wp_enqueue_script( 'testimonial-slider-main-script', plugins_url( 'assets/js/theme.js', __FILE__ ), [], '1.0.0', true );
	}

	// register custom category
    public function register_elementry_addons_category() {
        // Define your custom category slug and title
        $category_slug = 'elementry-addons-category';
        $category_title = __( 'Elementry Addons', 'elementry-addons' );

        // Get existing categories
        $existing_categories = \Elementor\Plugin::instance()->elements_manager->get_categories();

        // Check if the category already exists
        if ( ! array_key_exists( $category_slug, $existing_categories ) ) {
            // Register the new category
            \Elementor\Plugin::instance()->elements_manager->add_category(
                $category_slug,
                [
                    'title' => $category_title,
                    'icon'  => 'fa fa-plug', // Optional: Font Awesome icon or custom icon
                ],
                1 // Priority (position in the panel, 1 to place it near the top)
            );
        }
    }

	// register widgets
	public function register_elementry_addons_widgets() {
		require_once( __DIR__ . '/widgets/simple-card.php' );
		require_once( __DIR__ . '/widgets/pulse-effect.php' );
	}

}

// Instantiate the class
new \ElementryAddons\Elementry();